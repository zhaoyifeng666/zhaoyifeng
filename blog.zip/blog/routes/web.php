<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
// //映射控制器
// Route::get("user","UserController@user");

// // //映射视图
// // Route::get('user',function(){
// //     return view('user.user');
// // });
// //判断加百度
// Route::get('user/{id}',function($id){
//     if($id<3){
//         return redirect("https://www.baidu.com/");
//     }else{
//         echo "qwe";
//     }
// })->where('id','\d*');
// //路由前缀
// Route::prefix('admin')->group(function () {
//     Route::get('user', function () {
//         echo "前缀";
//     });
//     // Route::get('add','UserController@add');

//     Route::get('list','UserController@list');
// });
// Route::get('user','User\UserController@user');



Route::get('add','Add\AddController@add');
Route::post('insert','Add\AddController@insert');
Route::any('list','Add\AddController@list');
Route::post('del','Add\AddController@del');
Route::any('update','Add\AddController@update');
Route::any('updatedo','Add\AddController@updatedo');
Route::post('asdasdasdasd','Add\AddController@asdasdasdasd');
Route::post('gai','Add\AddController@gai');

Route::get('index','Index\IndexController@index')->middleware('index');
Route::get('userpage','Index\IndexController@userpage');
Route::get('register','Index\IndexController@register')->middleware('register');
Route::post('registerAdd','Index\IndexController@registerAdd');
Route::get('login','Index\IndexController@login');
Route::post('loginDo','Index\IndexController@loginDo');
Route::any('goodsList','Index\GoodsController@goodsList');
// Route::any('t1','Index\IndexController@t1');
Route::any('getCode','Index\IndexController@getCode');
Route::post('indexInfo','Index\IndexController@indexInfo');

Route::any('goodsCate','Index\goodsController@goodsCate');
Route::any('cateInfo','Index\goodsController@cateInfo');
Route::any('cateInfos','Index\goodsController@cateInfos');
Route::any('infoadd','Index\goodsController@infoadd');
Route::any('goodsCart','Index\goodsController@goodsCart');
Route::any('listCart','Index\goodsController@listCart');
Route::post('goodsDel','Index\goodsController@goodsDel');
Route::post('zongjia','Index\goodsController@zongjia');
Route::post('scartAdd','Index\goodsController@scartAdd');
Route::post('scartMin','Index\goodsController@scartMin');
Route::post('cartAllDel','Index\goodsController@cartAllDel');
Route::post('goodsValue','Index\goodsController@goodsValue');
// Route::get('cartshow','Index\goodsController@cartshow');



Route::any('cartList','Index\CartController@cartList');
Route::get('cartshow','Index\CartController@cartshow');
Route::any('witeaddr','Index\CartController@witeaddr');
Route::post('witeaddradd','Index\CartController@witeaddradd');
Route::post('isuser','Index\CartController@isuser');
Route::any('address','Index\CartController@address');
Route::any('addressdel','Index\CartController@addressdel');
Route::any('addressupdatelist','Index\CartController@addressupdatelist');
Route::any('witeaddrupdate','Index\CartController@witeaddrupdate');
Route::any('addgai','Index\CartController@addgai');
Route::any('orderpay','Index\CartController@orderpay');



Route::any('userprofile','Index\UserController@userprofile');