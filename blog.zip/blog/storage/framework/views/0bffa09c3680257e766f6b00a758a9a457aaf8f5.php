<script src="/js/jquery-3.2.1.min.js"></script>
<form action="" method="POST">
    <table>
        <tr>
            <td><input type="text" name="username"></td>
            <td>
                <input type="submit" value="提交">
            </td>
        </tr>
    </table>
</form>