@foreach($info as $v)

    <li id="23468">    
        <span class="gList_l fl">        
        <a href="goodsList?goods_id={{$v->goods_id}}">
            <img class="lazy" src="{{URL::asset('goodsimg/'.$v->goods_img)}}">
        </a>
        </span>    
        <div class="gList_r">        
        <a href="goodsList?goods_id={{$v->goods_id}}">
            <h3 class="gray6">{{$v->goods_name}}</h3>
            </a>        
            <em class="gray9">价值：￥{{$v->goods_selfprice}}</em>
            <div class="gRate">            
                <div class="Progress-bar">    
                    <p class="u-progress">
                        <span style="width: 91.91286930395593%;" class="pgbar">
                            <span class="pging"></span>
                        </span>
                    </p>                
                    <ul class="Pro-bar-li">
                        <li class="P-bar01"><em></em>已参与</li>
                        <li class="P-bar02"><em></em>总需人次</li>
                        <li class="P-bar03"><em></em>剩余</li>
                    </ul>            
                </div>    
                 <a codeid="12785750" class="uper" canbuy="646" goods_id="{{$v->goods_id}}"><s></s></a>     
                        
            </div>    
        </div>
    </li>

@endforeach
</body>
</html>
<script>
 layui.use('layer', function(){
            var layer=layui.layer;
            $('.uper').click(function(){
                var _this=$(this);
                var goods_id=_this.attr('goods_id');
                // console.log(goods_id);
                $.post(
                    'goodsCart',
                    {goods_id:goods_id},
                    function(res){
                        if(res.code==0){
                            layer.msg(res.font);
                            $('#bnm').html(res.num);
                        }else if(res.code==1){
                            layer.msg(res.font,{time:3000})
                            location.href='login';
                        }else{
                            layer.msg(res.font)
                        }
                        
                    },'json'
                )
            })
        })
</script>