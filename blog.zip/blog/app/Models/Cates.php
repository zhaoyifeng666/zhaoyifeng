<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Cates extends Model
{
    protected $table='cates';
    protected $primaryKey='cate_id';
    public $timestamps=false;
}
