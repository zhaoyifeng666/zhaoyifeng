<?php

namespace App\Http\Controllers\Add;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Models\chaoji;

class AddController extends Controller
{
    //查询
    public function add(){
        $sql="SELECT * FROM cate";
        $data = DB::select($sql);
        return view('add.add',['data'=>$data]);
    }
    //添加
    public function insert(Request $request){
        $data=$request->input();
        $res=DB::table('chaoji')->insert($data);
        if($res){
            echo 1;
          }else{
            echo 2;
          }
    }
    //展示
    public function list(request $request){
        // $sql="SELECT * FROM chaoji join cate on chaoji.cate_id=cate.cate_id where is_del=1";
        // $data = DB::select($sql);
        $is_hot=$request->input('is_hot');
        $is_up=$request->input('is_up');
        // $is_hot= substr($data,0,strpos($data,','));
        // // print_r($arr);exit;
        // $is_up= substr($data,strpos($data,'=')+1);
        // print_r($arr);exit;

        // print_r($is_hot);exit;
        if((!empty($is_hot)) || (!empty($is_up))){
            if((!empty($is_hot)) && (!empty($is_up))){
                $where=[
                    'is_hot'=>$is_hot,
                    'is_up'=>$is_up
                ];
            }else{
                if(!empty($is_hot)){
                    $where=[
                        'is_hot'=>$is_hot
                    ];
                }
                if(!empty($is_up)){
                    $where=[
                        'is_up'=>$is_up
                    ];
                }
            }
            
            $data = DB::table('chaoji')
            ->join('cate','chaoji.cate_id','=','cate.cate_id')
            ->where('is_del','=',1)
            ->where($where)
            ->select()
            ->paginate(2);
            $alldata=[
                'data'=>$data,
            ];
            return json_encode($alldata);
            return view('add.list',['is_hot'=>$is_hot,'is_up'=>$is_up])->with('data',$data);
        }else{
            $is_hot='';
            $is_up='';
            $data = DB::table('chaoji')
            ->join('cate','chaoji.cate_id','=','cate.cate_id')
            ->where('is_del','=',1)
            ->select()
            ->paginate(2);
            return view('add.list',['is_hot'=>$is_hot,'is_up'=>$is_up])->with('data',$data);
        }  
    }
    //删除
    public function del(request $request){
        $id=$request->input('id');
        $sql="UPDATE chaoji SET is_del=2 WHERE id=$id";
        $res=DB::update($sql);
        if($res){
            echo "ok";
        }else{
            echo "no";
        }
    }
    //修改
    public function update(request $request){
        $sql="SELECT * FROM cate";
        $datas = DB::select($sql);

        $id=$request->input('id');
        $where=[
            'id'=>$id
        ];
        $data=DB::table('chaoji')->where($where)->first();
        return view('add.update',['data'=>$data], ['datas'=>$datas]);
    }
    //执行修改
    public function updatedo(request $request){
        $data=$request->input();
        $id=$request->input('id');
        $where =[
            'id'=>$id
        ];
        $sql=DB::table('chaoji')->where($where)->update($data);
        if($sql){
            echo "1";
        }else{
            echo "2";
        }
        
    }
    //搜索
    public function asdasdasdasd(request $request){
        $is_hot=$request->input('is_hot');
        $is_up=$request->input('is_up');
        // echo $is_up;exit;
        $where=1;
        // echo $where;exit;
        if(!empty($is_hot)){
            $where.=" '";
        }
        if(!empty($is_up)){
            $where.=" and is_up = '$is_up'";
        }
        $data = DB::table('chaoji')->where($where)->first();
        return view('add.list',['data'=>$data]);
    }
    //即点即改
    public function gai(request $request){
        $data=$request->input();
        $id=$request->input('id');
        $where=[
            'id'=>$id
        ];
        $asd=[
            'username'=>$data['username']
        ];
        $sql=DB::table('chaoji')->where($where)->update($asd);
    }
    
}
