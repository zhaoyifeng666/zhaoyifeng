<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    public function user(Request $request){
        $arr=$request->input();
        //  echo "地对地导弹";
        //  print_r($arr);
        //创建视图  控制器加载
        return view('user.user');
    }

    public function add(){
        echo "路由前缀";

        $url = url('admin/list');
        return redirect($url);
    }

    public function list(){
        echo "辅助函数";
    }

    public function asdasd(){
        // //添加
        // $sql="INSERT INTO lianxi(username,age) values('name','18')";
        // $bol = DB::insert($sql);
        // var_dump($bol);

        // //修改
        // $sql="UPDATE lianxi SET username='names' where id=2";
        // $bol = DB::update($sql);
        // var_dump($bol);

        // //删除
        // $sql = "DELETE FROM lianxi WHERE id=2";
        // $bol = DB::delete($sql);
        // var_dump($bol);

        // //查询
        // $sql="SELECT * FROM lianxi WHERE id=1";
        // $bol = DB::select($sql);
        // print_r($bol);
    }
}
