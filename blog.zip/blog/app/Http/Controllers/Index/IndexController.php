<?php

namespace App\Http\Controllers\Index;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class IndexController extends Controller
{
    /**展示 */
    public function index(){
        $data = DB::table('goods')->where('goods_recommend',1)->limit(2)->get(['goods_id','goods_name','goods_img','goods_selfprice']);

        return view('index.index.index',['data'=>$data]);
    }
    /**流加载 */
    public function indexInfo(Request $request){
        $arr = array();
        $page = $request->input('page',1);
        // echo $page;
        $pageNum = 6;
        $offset = ($page-1)*$pageNum;

        $hotWhere=[
            'goods_hot'=>1
        ];
        $goodsHotInfo=DB::table('goods')
        ->offset($offset)
        ->limit($pageNum)
        ->where($hotWhere)
        ->get(['goods_id','goods_name','goods_img','goods_selfprice','goods_salenum']);
        $totalData = DB::table('goods')->count();
        $pageTotal = ceil($totalData/$pageNum); //总页数
        $objview =view('index.index.listdo',['info'=>$goodsHotInfo]);
        $content = response($objview)->getContent();
        $arr['info']=$content;
        $arr['pageTotal']=$pageTotal;
        $arr['page']=$page;
        return $arr;
    }
    /**注册页面 */
    public function register(){
        return view('index.login.register');
    }
    /**验证码*/
    public function getCode(Request $request){
        $tel=$request->input('tel');
        // $num='1234';
        $num = rand(1000,9999);
        $obj = new \send();
        $tel = "$tel";
        $bol = $obj->show($tel,$num);

        if($bol == 100){
            $time=time()+240;
            $arr = array(
                'code'=>$num,
                'tel'=>$tel,
                'timeout'=>$time,
            );
            
            $data = DB::table('code')->insert($arr);
            if($data){
                // session($where);
                echo json_encode(['font'=>'发送成功']);exit;
            }else{
                echo json_encode(['font'=>'发送失败']);exit;
            }
        }else{
            echo json_encode(['font'=>'发送失败']);exit;
        }

    }
    /**执行注册 */
    public function registerAdd(Request $request){
        $data=$request->input();
        $user_tel=$request->input('user_tel');
        $user_pwd=$request->input('user_pwd');
        $user_pwd1=$request->input('user_pwd1');
        $code=$request->input('code');

        




        if($user_pwd != $user_pwd1){
            echo json_encode(['font'=>'两次密码不一致']);exit;
        }
        $where=[
            'user_tel'=>$user_tel
        ];
        $tel = DB::table('user')->where($where)->first();
        if(!empty($tel)){
            echo json_encode(['font'=>'该手机号已注册']);exit;
        }

        $time=time();
        $codeWhere= array(
            'tel'=>$user_tel,
            'code'=>$code,
            'status'=>1
        );
        $sql= DB::table('code')->where($codeWhere)->first();
        if($sql){
            if($time>$sql->timeout){
                echo json_encode(['font'=>'验证码已失效']);exit;
            }
        }else{
            echo json_encode(['font'=>'验证码错误']);exit;
        }


        $user_pwd=md5($user_pwd);
        $info=[
            'user_tel'=>$user_tel,
            'user_pwd'=>$user_pwd,
        ];
        $sql = DB::table('user')->insert($info);
        if(!empty($sql)){

            $updateWhere = array(
                'tel'=>$user_tel,
                'code'=>$code
            );
            $statusData = array(
                'status'=>2
            );
            $update= DB::table('code')->where($updateWhere)->update($statusData);

            echo json_encode(['font'=>'注册成功']);exit;
        }else{
            echo json_encode(['font'=>'注册失败']);exit;
        }
    }
    /**登录页面 */
    public function login(){
        return view('index.login.login');
    }
    /**执行登录 */
    public function loginDo(Request $request){
        $data=$request->input();
        $user_tel=$request->input('user_tel');
        $user_pwd=$request->input('user_pwd');
        $user_pwd=md5($user_pwd);
        $where=[
            'user_tel'=>$user_tel,
            'user_pwd'=>$user_pwd
        ];
        $date=DB::table('user')->where($where)->first();
        // print_r($date);exit;
        $user_id=$date->user_id;
        // echo $user_id;exit;
        if(!empty($date)){
            session(['user_id'=>$user_id]);
           //echo json_encode(['font'=>'登录成功']);exit;
           return ['font'=>'登录成功'];
        }else{
            echo json_encode(['font'=>'手机号或密码错误']);exit;
        }

    }
    /**我的潮购 */
    public function userpage(Request $request){
        $user_id=$request->session()->get('user_id');
        
        return view('index.user.userpage');
    }
    /**验证码 */
    // public function t1(Request $request){
    //     $obj = new \send();
    //     $tel = '18837342460';
    //     $obj->show($tel);
    // }
}
