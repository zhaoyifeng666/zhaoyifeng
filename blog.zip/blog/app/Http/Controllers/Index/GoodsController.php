<?php

namespace App\Http\Controllers\Index;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Models\Cates;
use App\Models\Goods;
use App\Models\Cart;

class GoodsController extends Controller
{
    /**分类页面*/
    public function goodsCate(){
        $data = DB::table('cates')->where('p_id',0)->get(['cate_name','cate_id']);
        return view('index.goods.goodscate',['data'=>$data]);
    }
    /**查询商品 */
    public function cateInfo(Request $request){
        DB::enableQueryLog();
        $arr = array();
        $cate_id = $request->input('cate_id');
        $page = $request->input('page');
        $pageNum = 20;
        $offset = ($page-1)*$pageNum;
        if(empty($cate_id)){
            $goodsHotInfo=DB::table('goods')
            ->orderBy('goods_selfprice','ase')
            ->offset($offset)
            ->limit($pageNum)
            ->get(['goods_id','goods_name','goods_img','goods_selfprice','goods_salenum']);
            
            $totalData = DB::table('goods')->count();

        }else{
            // $cate_id_all=[];
            $cateInfos = Cates::get();
            // foreach($cateInfos as $k=>$v){
            //     if($v->pid ==$cate_id){
            //         $cate_id_all[]=$v->cate_id;
            //     }
            // }
            // $cateInfos = DB::table('cates')->get();
            $cate_id = $this->getCateId($cateInfos,$cate_id);
            //   print_r($cate_id);exit;

            
            $goodsHotInfo=Goods::orderBy('goods_selfprice','ase')
            ->limit($pageNum)
            ->whereIn('cate_id',$cate_id)
            ->offset($offset)
            ->get(['goods_id','goods_name','goods_img','goods_selfprice','goods_salenum']);
            // dd(\DB::getQueryLog());exit;
            // print_r($goodsHotInfo);exit;
            $totalData = DB::table('goods')->where('cate_id',$cate_id)->count();
        }
        $pageTotal = ceil($totalData/$pageNum); //总页数
        $objview =view('index.goods.catedo',['info'=>$goodsHotInfo]);
        $content = response($objview)->getContent();
        $arr['info']=$content;
        $arr['pageTotal']=$pageTotal;
        $arr['page']=$page;
        return $arr;
    }
    /** 获取当前分类下的所有子类ID */
    public function getCateId($cateInfos, $p_id){
        static $cateId = [];
        foreach ($cateInfos as $k => $v) {
            if ($v['p_id'] == $p_id) {
                $cateId[] = $v['cate_id'];
                $this->getCateId($cateInfos, $v['cate_id']);
            }
        }
        return $cateId;
    }
    /**详情页 */
    public function goodsList(Request $request){
        $goods_id=$request->input('goods_id');
        $user_id=$request->session()->get('user_id');
        // print_r($goods_id);exit;
        $data = DB::table('goods')->where('goods_id',$goods_id)->get(['goods_id','goods_name','goods_img','goods_selfprice']);
        // print_r($data);
        $cartInfo= DB::table('cart')->where('user_id',$user_id)->get()->toArray();
        $buy_num=array_column($cartInfo,'buy_number');
        $buy_number=array_sum($buy_num);
        return view('index.goods.goodslist',['data'=>$data],['buy_number'=>$buy_number]);
    }
    /**是否加入购物车*/
    public function goodsCart(Request $request){
        $goods_id=$request->input('goods_id');
        // $user_tel=$request->session()->get('user_tel');
        $user_id=$request->session()->get('user_id');
        // var_dump($user_id);exit;
        if(!$user_id){
            echo json_encode(['font'=>'请先登录','code'=>1]);exit;
        }
        $where=[
            'goods_id'=>$goods_id,
            'goods_up'=>1
        ];
        $data = DB::table('goods')->where($where)->first();
        //商品总数量
        $goods_num=$data->goods_num;
        $cartwhere=[
            'goods_id'=>$goods_id,
        ];
        $cartdata = DB::table('cart')->where($cartwhere)->first();
        if(!$cartdata){
            if($goods_num<1){
                echo json_encode(['font'=>'库存不足','code'=>2]);exit;
            }else{
                $cartwheres=[
                    'goods_id'=>$goods_id,
                    'user_id'=>$user_id,
                    'is_del'=>1,
                    'buy_number'=>1,
                    'create_time'=>time(),
                    'add_price'=>$data->goods_selfprice
                ];
                $cartdata = DB::table('cart')->insert($cartwheres);
                $cartInfo= DB::table('cart')->where('user_id',$user_id)->get()->toArray();
                $buy_num=array_column($cartInfo,'buy_number');
                $buy_number=array_sum($buy_num);
                echo json_encode(['font'=>'加入购物车成功','code'=>0,'num'=>$buy_number]);exit;
            }
            
        }
        $buy_number=$cartdata->buy_number+1;
        // print_r($buy_number);exit;
        if($goods_num<$buy_number){
            echo json_encode(['font'=>'库存不足','code'=>2]);exit;
        }
        $whereupdate=[
            'buy_number'=>$buy_number,
            'is_del'=>1,
            'update_time'=>time()
        ];
        $cartdata = DB::table('cart')->where('goods_id',$goods_id)->update($whereupdate);
        $cartInfo= DB::table('cart')->where('user_id',$user_id)->get()->toArray();
        $buy_num=array_column($cartInfo,'buy_number');
        $buy_number=array_sum($buy_num);
        echo json_encode(['font'=>'加入购物车成功','code'=>0,'num'=>$buy_number]);exit;
    }
    /**购物车页面 */
    public function listCart(Request $request){
        $user_id=$request->session()->get('user_id');
        $where=[
            'user_id'=>$user_id,
            'is_del'=>1
        ];
        $cartInfo=DB::table('cart')->join('goods','cart.goods_id','=','goods.goods_id')->where($where)->get();

        $infodata = DB::table('goods')->where('goods_hot',1)->limit(4) ->get(['goods_id','goods_name','goods_img','goods_selfprice','goods_salenum']);

        if($cartInfo){
            $cartInfo=$cartInfo->toArray();
        }else{
            $cartInfo=[];
        }
        $cartnum=count($cartInfo);
        // print_r($cartnum);exit;
        return view('index.goods.goodscart',['info'=>$cartInfo,'cartnum'=>$cartnum],['infodata'=>$infodata]);
    }
    /**购物车删除 */
    public function goodsDel(Request $request){
        $goods_id=$request->input('goods_id');
        $user_id=$request->session()->get('user_id');
        $where=[
            'goods_id'=>$goods_id,
            'user_id'=>$user_id
        ];
        $data=[
            'is_del'=>2,
            'buy_number'=>0
        ];
        $sql= DB::table('cart')->where($where)->update($data);
        if($sql){
            return 1;
        }else{
            return 2;
        }
    }
    /**加号 */
    public function scartAdd(Request $request){
        $goods_id=$request->input('goods_id');
        $data = DB::table('goods')->where('goods_id',$goods_id)->first();
        $goods_num=$data->goods_num;
        $datacart = DB::table('cart')->where('goods_id',$goods_id)->first();
        $buy_number=$datacart->buy_number+1;
        // print_r($xxxxxx);exit;
        if($buy_number > $goods_num){
            $arr = [
                'msg'=>'库存不足',
                'num'=>0
            ];
            return $arr;
        }
        $numdata=[
            'buy_number'=>$buy_number,
            'update_time'=>time()
        ];
        $asfd=DB::table('cart')->where('goods_id',$goods_id)->update($numdata);

    }
    /**减号 */
    public function scartMin(Request $request){
        $goods_id=$request->input('goods_id');
        $datacart = DB::table('cart')->where('goods_id',$goods_id)->first();
        $buy_number=$datacart->buy_number-1;
        $numdata=[
            'buy_number'=>$buy_number,
            'update_time'=>time()
        ];
        $asfd=DB::table('cart')->where('goods_id',$goods_id)->update($numdata);
    }
    /**批量删除 */
    public function cartAllDel(Request $request){
        $goods_id=$request->input('goods_id');
        // print_r($goods_id);exit;
        $user_id=$request->session()->get('user_id');
        $cartUpdate=[
            'is_del'=>2,
            'buy_number'=>0,
            'update_time'=>time()
        ];
        $res = Cart::where('user_id',$user_id)->whereIn('goods_id',$goods_id)->update($cartUpdate);
        // print_r($res);exit;
        if($res){
            $arrs=['num'=>1,'msg'=>'删除成功'];
            return $arrs;
        }else{
            $arrs=['num'=>0,'msg'=>'删除失败'];
            return $arrs;
        }
    }
    /**修改文本框的值 */
    public function goodsValue(Request $request){
        $goods_value=$request->input('goods_value');
        $goods_id=$request->input('goods_id');
        $data = DB::table('goods')->where('goods_id',$goods_id)->first();
        $goods_num=$data->goods_num;
        if($goods_value>$goods_num){
            $datacart = DB::table('cart')->where('goods_id',$goods_id)->first();
            $buy_number=$datacart->buy_number;
            $numdata=[
                'buy_number'=>$goods_num,
                'update_time'=>time()
            ];
            $asfd=DB::table('cart')->where('goods_id',$goods_id)->update($numdata);
            $arr = [
                'num'=>1,
                'msg'=>'库存不足',
                'buy_number'=>$goods_num
            ];
            return $arr;
        }
        $numdata=[
            'buy_number'=>$goods_value,
            'update_time'=>time()
        ];
        $asfd=DB::table('cart')->where('goods_id',$goods_id)->update($numdata);

    }









    public function infoadd(){
        $arr = array(
            array('id'=>1,'name'=>'lisi','age'=>20),
            array('id'=>2,'name'=>'lisi','age'=>50),
            array('id'=>3,'name'=>'lisi','age'=>10),
            array('id'=>4,'name'=>'lisi','age'=>9),
            array('id'=>5,'name'=>'lisi','age'=>4),
        );
        $arr1 =array();
        foreach ($arr as $k=>$v){
            // print_r($k);exit;
            $arr1[$v['age']]=$v;
        }
        // print_r($arr1);exit;
        $arr2 = array();
        foreach($arr as $k=>$v){
                $arr2[] = $v['age'];
        }
        // print_r($arr2);exit;
        sort($arr2);
        $arr3 = array();
        foreach($arr2 as $v){
            print_r($v);exit;
            $arr3[] = $arr1[$v];
        }
    

    }

}
