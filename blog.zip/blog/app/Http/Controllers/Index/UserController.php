<?php

namespace App\Http\Controllers\Index;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Models\Cates;
use App\Models\Goods;
use App\Models\Cart;
use App\Models\Address;
use App\Models\Order;

class UserController extends Controller
{
    /**潮购记录 */
    public function userprofile(Request $request){
        $user_id=$request->session()->get('user_id');

        $data = DB::table('order_detail')->where('user_id',$user_id)->get();
        return view('index.user.userprofile',['data'=>$data]);
    }

}