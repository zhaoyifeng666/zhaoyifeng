<?php

namespace App\Http\Controllers\Index;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Models\Cates;
use App\Models\Goods;
use App\Models\Cart;
use App\Models\Address;
use App\Models\Order;

class CartController extends Controller
{
    /**订单生成 */
    public function cartList(Request $request){
        $goods_id=$request->input('goods_id');
        $zongjia=intval($request->input('zongjia'));
        // var_dump($zongjia);exit;
        $user_id=$request->session()->get('user_id');
        if(empty($user_id)){
            $arr= ['num'=>1,'msg'=>'未登录，请先登录'];
            return $arr;
        }
        if(empty($goods_id)){
            $arr= ['num'=>0,'msg'=>'请选择你要购买的商品'];
            return $arr;
        }
        //订单号
        $order_no = date("YmdHis",time()).rand(1000,9999);

        //添加订单表
        $dataorder = [
            'user_id'=>$user_id,
            'order_amount'=>$zongjia,
            'order_no'=>$order_no,
            'order_pay_type'=>1,
            'pay_status'=>1,
            'pay_way'=>1,
            'status'=>1,
            'create_time'=>time()
        ];
        $infodata =DB::table('order')->insert($dataorder);
        $dataData = DB::table('order')->where('order_no',$order_no)->first();
        $order_id = $dataData->order_id;
        session(['order_id'=>$order_id]);
        // $tiaojian = [
        //     'user_id'=>$user_id,
        //     'goods_id'=>$goods_id
        // ];

        // $asdasd = DB::table('cart')->where($tiaojian)->get();



        // print_r($order_id);exit;
        $cartUpdate=[
            'is_del'=>2,
            // 'buy_number'=>0,
            'update_time'=>time()
        ];
        $res = Cart::where('user_id',$user_id)->whereIn('goods_id',$goods_id)->update($cartUpdate);
        //添加订单详情表
        $num = Cart::join('goods','goods.goods_id','=','cart.goods_id')->whereIn('goods.goods_id',$goods_id)->get();
        foreach($num as $k=>$v){
            $info=[
                'user_id'=>$user_id,
                'order_id'=>$order_id,
                'order_no'=>$order_no,
                'goods_id'=>$v['goods_id'],
                'goods_name'=>$v['goods_name'],
                'goods_selfprice'=>$v['goods_selfprice'],
                'goods_img'=>$v['goods_img'],
                'buy_number'=>$v['buy_number'],
                'goods_status'=>1,
                'create_time'=>time()
            ];
            $datailData = DB::table('order_detail')->insert($info);
        }

        $UpdateNum=[
            // 'is_del'=>2,
            'buy_number'=>0,
            'update_time'=>time()
        ];
        $res = Cart::where('user_id',$user_id)->whereIn('goods_id',$goods_id)->update($UpdateNum);



        return $arr=['num'=>3,'order_id'=>$order_id];

    }
    /**订单展示页面地址 */
    public function cartshow(Request $request){
        $user_id=$request->session()->get('user_id');
        $order_id=$request->input('order_id');
        $orderDetailWhere=[
            'order.order_id'=>$order_id,
            'order.user_id'=>$user_id
        ];
        $goodsInfo=Order::where($orderDetailWhere)
            ->join('order_detail','order.order_id','=','order_detail.order_id')
            ->get();
        $defaultWhere=[
            'user_id'=>$user_id,
            'is_default'=>1
        ];
        $addressDefault=Address::where($defaultWhere)->first();
        if($addressDefault){
            $addressDefault=$addressDefault->toArray();
        }else{
            $addressDefault=[];
        }
        $addressnum=count($addressDefault);
        $amount = DB::table('order')->where($orderDetailWhere)->first();
        return view('index.carts.cartshow',['goodsInfo'=>$goodsInfo,'order_id'=>$order_id,'addressnum'=>$addressnum,'addressDefault'=>$addressDefault],['amount'=>$amount]);
    }
    /**添加地址页面 */
    public function witeaddr(){
        return view('index.carts.writeaddr');
    }
    /** 判断订单*/
    public function isuser(Request $request){
        $user_id=$request->session()->get('user_id');
        if(empty($user_id)){
            $arr = ['num'=>1,'msg'=>'未登录'];
            return $arr;
        }
        $data = DB::table('address')->where('user_id',$user_id)->first();
        if(!$data){
            $arr=[
                'num'=>0,
                'msg'=>'未添加收货地址'
            ];
            return $arr;
        }else{
            $arr=[
                'num'=>2,
            ];
        }
        
    }
    /**地址管理 */
    public function address(Request $request){
        $address_id=$request->input('address_id');

        $order_id=$request->session()->get('order_id');
        $user_id=$request->session()->get('user_id');
        $data = DB::table('address')->where('user_id',$user_id)->get();
        $wherelist=[
            'order_id'=>$order_id,
            'user_id'=>$user_id
        ];
        $amount = DB::table('order')->where($wherelist)->first();

        return view('index.carts.address',['data'=>$data,'address_id'=>$address_id],['amount'=>$amount]);
    }
    /**地址管理的删除 */
    public function addressdel(Request $request){
        $add_id=$request->input('add_id');
        // print_r($add_id);exit;
        $where=[
            'is_del'=>0
        ];
        $sql = DB::table('address')->where('add_id',$add_id)->update($where);
        $arr = [
            'status'=>1
        ];
        return $arr;
    }
    /**地址管理的修改页面 */
    public function addressupdatelist(Request $request){
        $order_id=$request->session()->get('order_id');
        $add_id=$request->input('add_id');
        // print_r($order_id);exit;
        $data = DB::table('address')->where('add_id',$add_id)->first();

        return view('index.carts.witeadderupdate',['data'=>$data]);
    }
    /**地址管理的执行修改 */
    public function witeaddrupdate(Request $request){
        $add_id=$request->input('add_id');
        $add_name=$request->input('add_name');
        $add_tel=$request->input('add_tel');
        $add_province=$request->input('add_province');
        $add_details=$request->input('add_details');
        $is_default=$request->input('is_default');
        $user_id=$request->session()->get('user_id');

        $data = [
            'add_name'=>$add_name,
            'add_tel'=>$add_tel,
            'add_province'=>$add_province,
            'add_details'=>$add_details,
            'is_default'=>$is_default,
            'create_time'=>time()
        ];
        // exit;
        $sql = DB::table('address')->where('add_id',$add_id)->update($data);
        if($sql){
            echo 'ok';
        }else{
            echo 'no';
        }
    }
    /**默认修改 */
    public function addgai(Request $request){
        $add_id=$request->input('add_id');
        $user_id=$request->session()->get('user_id');
        // print_r($add_id);exit;
        $qwe = [
            'is_default'=>2
        ];
        $sql = DB::table('address')->where('user_id',$user_id)->update($qwe);
        $wherere=[
            'add_id'=>$add_id,
            'user_id'=>$user_id
        ];
        $ZCxzc = [
            'is_default'=>1
        ];
        $sql = DB::table('address')->where($wherere)->update($ZCxzc);
        if($sql){
            echo '1';
        }else{
            echo '2';
        }

    }
    /**地址入库 */
    public function witeaddradd(Request $request){
        $add_name=$request->input('add_name');
        $add_tel=$request->input('add_tel');
        $add_province=$request->input('add_province');
        $add_details=$request->input('add_details');
        $is_default=$request->input('is_default');
        $user_id=$request->session()->get('user_id');
        
        if($is_default == 1){
            $datasss = [
                'is_default'=>2
            ];
            $sql = DB::table('address')->where('user_id',$user_id)->update($datasss);
        }
        $data = [
            'add_name'=>$add_name,
            'add_tel'=>$add_tel,
            'add_province'=>$add_province,
            'add_details'=>$add_details,
            'is_default'=>$is_default,
            'user_id'=>$user_id,
            'create_time'=>time()
        ];
        // exit;
        $sql = DB::table('address')->insert($data);
        if($sql){
            return 'ok';
        }else{
            return 'no';
        }
    }


}