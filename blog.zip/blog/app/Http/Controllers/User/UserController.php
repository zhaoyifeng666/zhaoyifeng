<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class UserController extends Controller
{
    //
    public function user(){
        return view('index.index.user');
    }

    public function indexInfo(){
        $hotWhere=[
            'goods_hot'=>1
        ];
        $goodsHotInfo=DB::table('goods')->where($hotWhere)->get(['goods_id','goods_name','goods_img','goods_selfprice','goods_salenum']);
    }
}
